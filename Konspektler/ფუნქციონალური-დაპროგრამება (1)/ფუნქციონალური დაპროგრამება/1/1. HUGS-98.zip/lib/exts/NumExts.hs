module NumExts
	( doubleToFloat
	, floatToDouble
	) where

primitive doubleToFloat :: Double -> Float
primitive floatToDouble :: Float -> Double

